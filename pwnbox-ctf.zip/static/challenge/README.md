# CorpChat Backend — Source Mirror

This is a read-only mirror of the CorpChat backend repository,
exposed here for internal development reference.

## Hints

- The `.git/` directory is browseable.
- Try reconstructing the full commit history.
- Flag format: `CTF{...}`
